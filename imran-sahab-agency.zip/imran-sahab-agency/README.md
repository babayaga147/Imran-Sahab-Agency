# Imran Sahab Digital Agency: portfolio site

A single-file static site. Everything (styles, script, images) is inside `index.html`, so there is no build step.

## Deploy

**Vercel (drag and drop):** go to vercel.com/new, drop this folder in. Framework preset: Other. No build command, no output directory.

**Vercel CLI:** `cd imran-sahab-agency && npx vercel --prod`

**Netlify:** drag this folder onto app.netlify.com/drop.

**GitHub Pages / any host:** upload `index.html` to the web root.

## Edit

- WhatsApp number: search `923237150002` (links) and `0323 7150002` (display).
- Email: search `lazybrowndude@gmail.com`.
- Easy Fit Shoes link: search `easyfitshoescom.vercel.app`.
- Fonts load from Google Fonts. The hero 3D effect uses WebGL and falls back to a plain image.
